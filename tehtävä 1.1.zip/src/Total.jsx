import React from 'react';

const Total = (props) => {
  return <p>Number of exercises {props.totalExercises}</p>;
}

export default Total;
